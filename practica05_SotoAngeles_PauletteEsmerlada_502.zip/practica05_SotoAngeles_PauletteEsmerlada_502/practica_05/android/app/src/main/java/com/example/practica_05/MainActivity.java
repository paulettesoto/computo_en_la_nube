package com.example.practica_05;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
